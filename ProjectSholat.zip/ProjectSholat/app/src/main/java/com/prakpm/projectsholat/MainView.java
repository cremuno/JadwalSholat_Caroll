package com.prakpm.projectsholat;

import java.util.List;

public interface MainView {
    void onSuccess(List<SholatModel> sholatModels);
}
